<?php
namespace App\Core\Database;

use PDO;

class QueryBuilder {

    public $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    public function getAll($tablename) {
        // prepare a query
        $query = $this->pdo->prepare("SELECT * FROM {$tablename}");

        // execute a query
        $query->execute();

        // fetch data
        return $query->fetchAll(PDO::FETCH_OBJ);
    }

    public function getAllPosts(){
        $query = $this->pdo->prepare("SELECT posts.*, users.name as author, categories.title as category FROM posts 
LEFT JOIN users ON posts.user_id = users.id LEFT JOIN categories ON posts.category_id = categories.id");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_OBJ);
    }
    public function getCategoryPosts($categoryId){
        $query = $this->pdo->prepare("SELECT posts.* from posts where category_id={$categoryId}");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_OBJ);
    }
    public function getOnePost($id){
        $query = $this->pdo->prepare("SELECT posts.* from posts where id={$id}");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_OBJ);
    }

    public function insert($table, $parameters) {

        $sql = sprintf("INSERT INTO %s (%s) VALUES(%s)",
            $table,
            implode(", ", array_keys($parameters)),
            ":" . implode(", :", array_keys($parameters))) ;


        $query = $this->pdo->prepare($sql);

        $query->execute($parameters);

    }

    public function update($table, $parameters, $id) {

        $keys = "";
        foreach ($parameters as $key => $parameter) {
            $keys .= $key . ' = "' . $parameter .'",';
        }
        $keys= substr($keys, 0 , -1);

        $sql = sprintf("UPDATE %s SET %s WHERE id = '%s'",
            $table, $keys, $id);

        $query = $this->pdo->prepare($sql);

        $query->execute($parameters);

    }

    public function find($tablename, $id)
    {
        $query = $this->pdo->prepare("SELECT * FROM {$tablename} WHERE id = '{$id}'");
        $query->execute();
        return $query->fetch(PDO::FETCH_OBJ);
    }

    public function delete($tablename, $id) {

        $query = $this->pdo->prepare("DELETE FROM {$tablename} WHERE id = '{$id}'");
        $query->execute();
    }

    public function authenticate($email, $password)
    {
        $query = $this->pdo->prepare("SELECT * FROM users WHERE email = '{$email}' AND password='{$password}'");
        $query->execute();
        return $query->fetch(PDO::FETCH_OBJ);
    }
    public function register($email, $password)
    {
        $query = $this->pdo->prepare("SELECT * FROM users WHERE email = '{$email}'");
        $query->execute();
        if ($query->fetchColumn()>0)
            return 0;
        $query1 = $this->pdo->prepare("INSERT INTO users(email, password) VALUES ('{$email}','{$password}')");
        //$query1->debugDumpParams();
        $query1->execute();
        return 1;
    }

}

