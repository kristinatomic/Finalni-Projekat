<?php require "partials/header.view.php" ?>
    This is main dashboard

    <a href="#" id="login-button">Login here</a>
    <div class="row login-form">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-body">

                    <form action="/login" method="post">
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="text" name="email" id="email" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" name="password" id="password" class="form-control">
                        </div>

                        <button class="btn btn-primary pull-right">Login</button>


                    </form>


                </div>
            </div>
        </div>
    </div>
    <div id="app">
        Currrent time is : {{date}}
        <ul>
            <li v-for="user in users">{{user.name}}</li>
        </ul>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.4.1/vue.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.16.2/axios.min.js"></script>

    <script>
        new Vue({
            el: "#app",
            data: {
                test: "asldklas",
                users: [],
                date: ""
            },
            mounted() {
                axios.get('/api/users').then( (response) => {

                    this.users = response.data
                });

                axios.get('/api/time').then( (response) => {
                    console.log(response)
                this.date = response.
                    data.date
            });
            }
        });
    </script>
<?php require "partials/footer.view.php" ?>