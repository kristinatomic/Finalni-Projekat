<template>
    <div>
        <div class="slide">
            <img src="images/slide2.jpg"/>
        </div>

<!-- slide end -->

<!-- colection -->
<div class="colectionn">
LATEST COLLECTION
</div>
      
<div class="nova">
            <a v-for="post in posts"  :href="'product/?id='+post.id">
                <img :src="'/images/products/'+post.image" />
                    <span>{{post.title}}<br /><h2>{{post.price}}</h2></span>
            </a>
</div>

    </div>
</template>
<script>
    export default {
        data: function(){
            return {
                posts: [],
                title: "",
                content: ""

            }
        },
        mounted() {
            this.getAllPosts();
        },
        methods: {
            getAllPosts() {
                axios.get('/api/posts')
                        .then((response) => {
                    this.posts  = response.data
            });
            },
            submitForm(){
                axios.post('/api/posts', {
                    title: this.title,
                    content: this.content
                }).then((response) =>  {
                    this.getAllPosts();
                    this.title = ""
                    this.content = ""
                })
            }
        }
    }
</script>
<style>

</style>