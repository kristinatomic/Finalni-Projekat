<template>
	<div>
		
	</div>
</template>

<script>
    export default {
        name: 'aboutUs'
    }
</script>

<style>

</style>