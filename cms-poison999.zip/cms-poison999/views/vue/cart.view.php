<?php get_header() ?>
<div style="width:80%; margin:5px auto 15px auto; text-align:center; font-size:5vh; color:#777; border-bottom:solid 5px #999;">Shopbag</div>

		<div style="width:80%; margin:5px auto 0px auto;">

		<div class="shop">
		<table id="shopbag" cellpadding="2" cellspacing="2" width="100%">


		</table>
		</div>
			<div style="width:80%; margin:5px auto 0px auto; text-align:right; padding-right:40px; font-size:3vh;">
			<a onclick="naruci()" class="naruci">NARUCI</a>
			</div>
		</div>
		<script>
		function render()
		{
			var cart = [];
	        if (localStorage.hasOwnProperty('cart'))
	            cart = JSON.parse(localStorage.getItem('cart'));
	        var render = "";
	        ukupnaCena=0;
	        for (let i=0; i<cart.length; i++)
	        {
				render+="<tr>";
				render+='<td width="50"><img src="'+cart[i].image+'" width="50" /></td>';
				render+='<td>'+cart[i].name+'</td>';
				render+='<td>'+cart[i].size+'</td>';
				render+='<td>'+cart[i].color+'</td>';
				render+='<td>Qty:'+cart[i].qty+'</td>';
				render+='<td>$'+cart[i].price+'</td>';
				render+='<td width="20"><a href="#" onclick="delItem('+i+')" style="text-decoration:none; color:#f00;"><h2>X</h2></a></td>';
				render+="</tr>";
				ukupnaCena+=Number(cart[i].price);
		    }
		    document.getElementById("shopbag").innerHTML=render;
		    numCart();
		}
		render();
	    function naruci()
	    {
	    	alert("Ordered "+numCart()+" articles with total price of "+ukupnaCena+"!");
	    	localStorage.removeItem("cart");
	    	render();
	    }
	    function delItem(i)
	    {
	    	var cart = [];
	        if (localStorage.hasOwnProperty('cart'))
	            cart = JSON.parse(localStorage.getItem('cart'));
	        cart.splice(i,1);
	        localStorage.setItem("cart",JSON.stringify(cart));
	        alert("Item deleted!");
	        render();
	    }
		</script>

<div id="app">

</div>
<?php get_footer() ?>