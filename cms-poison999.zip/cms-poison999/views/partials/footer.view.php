</main>
<script src="/views/vue/dist/build.js"></script>
<!-- social -->

<div class="soc">
<a href="#">SOCIAL</a>
<a href="http://www.facebook.com" target="new"><img src="/images/social/socf.png" /></a>
<a href="http://www.instagram.com" target="new"><img src="/images/social/soci.png" /></a>
<a href="http://www.pinteres.com" target="new"><img src="/images/social/socp.png" /></a>
<a href="http://www.youtube.com" target="new"><img src="/images/social/socy.png" /></a>
</div>

<div class="soc2">
<a href="#">WE ACCEPT</a>
<a href="#"><img src="/images/pay/payv.png" /></a>
<a href="#"><img src="/images/pay/paym.png" /></a>
<a href="#"><img src="/images/pay/payp.png" /></a>
</div>
<!-- social end -->

<!-- FUTER -->
<div class="futer">SHOPS</div>
<div class="futera">
<!-- Belgrade -->
<article>
<h3>Belgrade</h3>
<div>Kralja Milana 4</div>
<div><img src="/images/icons/icob.png" /> <span> +38162-35-654</span></div>
<div><img src="/images/icons/icoe.png" /> <span> ktom@belgrade.com</span></div>
</article>

<!-- London -->
<article>
<h3>London</h3>
<div>Dorset Street 12</div>
<div><img src="/images/icons/icob.png" /><span> +44-234-678</span></div>
<div><img src="/images/icons/icoe.png" /><span> ktom@london.com</span></div>
</article>

<!-- Paris -->
<article>
<h3>Paris</h3>
<div>10 Rue Saint-Antoine</div>
<div><img src="/images/icons/icob.png" /><span> +33 1 42 72 79</span></div>
<div><img src="/images/icons/icoe.png" /><span> ktom@paris.com</span></div>
</article>

</div>
<!-- FUTER end -->

</body>
</html>
