<!-- top -->
<div class="top">
<?php if (!isset($_SESSION["user"])) {?>
    <a href="/register">Register</a>
    <a href="/login">Login</a>
 <?php } else { ?>
 	<a href="/logout">Logout</a>
 	<?php }?>

</div>
<!-- top end -->

<!-- menu end -->
<div class="menu">
<a href="/categories" class="ba">MEN</a>
<a href="/categories">WOMEN</a>
<a href="/"><img src="/images/logo.png" width="100" height="80" /></a>
<a href="/aboutus" class="ba">About</a>
<a href="/cart">Cart <font id="numCart" size="+2" color="#f5f"></font></a>
<script>
function numCart()
{
	var numCart = 0;
	if (localStorage.hasOwnProperty('cart'))
		numCart = JSON.parse(localStorage.cart).length;
	document.getElementById("numCart").innerHTML=numCart;
	return numCart;
}
numCart();
</script>
</div>
<!-- menu end -->

<div class="box"></div>

<!-- HEADER m -->
<div class="header"><a href="/">
<img src="/images/logo.png" /></a>


</div>

<label for="m"><img src="/images/menu1.png" /></label><input class="mob" type="checkbox" id="m" />
<div class="menx">
<a href="/categories" class="ba">MEN</a>
<a href="/categories">WOMEN</a>
<a href="/aboutus" class="ba">About</a>
<a href="/cart">Cart</a>
<a href="/register">Register</a>
<a href="/login">Login</a>
</div>


<!-- HEADER m -->