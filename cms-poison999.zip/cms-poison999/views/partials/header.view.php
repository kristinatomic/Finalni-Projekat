<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/css/main.css">
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Butik shop</title>

<meta name="description" content="butik shop">
<meta name="keywords" content="muska odeca, zenska odeca">
<meta name="robots" content="all, index, follow" />
<meta name="googlebot" content="all, index, follow" />
<meta name="revisit-after" content="1 days" />
<meta name="location" content="RS">
<meta name="author" content="kristina.tmc@gmail.com">


</head>
<body>  
<?php get_nav() ?>
<main>