<?php get_header();  ?>
<?php $post=$posts[0];?>

<div class="prikaz">
<table border="0" cellspacing="2" cellpadding="1">
<input type="hidden" name="id" value="<?=$post->title?>" />
  <tr>
    <td rowspan="11" align="right" valign="top" >
      <img src="/images/products/<?=$post->image?>" /></td>
      <td rowspan="11" style="width:1%;" >
    <td><span class="v1"><?=$post->title?></span></td>
  </tr>
  <tr>
    <td><span class="m1">In stock</span></td>
  </tr>
  <tr>
    <td><span class="v1">$<?=$post->price?></span></td>
  </tr>
  <tr>
    <td><span class="m1"><?=$post->description?></span>
    </td>
  </tr>
  <tr>
      <td>Color
 <select name="color">
    <option value="">Please Select</option>
    <option value="red">red</option>
    <option value="green">green</option>
    <option value="blue">blue</option>
    </select>
    </td>
  </tr>
  <tr>
    <td>Manufacturers
     <select name="man">
    <option value="">Please Select</option>
    <option value="Levis">Levis</option>
    <option value="Nike">Nike</option>
    <option value="Adidas">Adidas</option>
    </select>
    </td>
  </tr>
  <tr>
    <td>Size
     <select name="size">
    <option value="">Please Select</option>
    <option value="Large">Large</option>
    <option value="Medium">Medium</option>
    <option value="AdidSmallas">Small</option>
    </select>
    </td>
  </tr>
  <tr>
    <td>Qty: <input type="number" name="komada" min="1" max="10" value="1"></td>
  </tr>
  <tr>
    <td><button onclick="addToCart()">Add to cart</button></td>
  </tr>
</table>

</div>

<div id="app">
</div>
<script>
    function addToCart()
    {
        var data = {
                "name":"<?=$post->title?>",
                "image":"/images/products/<?=$post->image?>",
                "price":"<?=$post->price?>",
                "color":document.getElementsByName("color")[0].value,
                "size":document.getElementsByName("size")[0].value,
                "qty":document.getElementsByName("komada")[0].value,
                "manufacturer":document.getElementsByName("man")[0].value
        };
        var cart = [];
        if (localStorage.hasOwnProperty('cart'))
            cart = JSON.parse(localStorage.getItem('cart'));
        cart.push(data);
        localStorage.setItem('cart',JSON.stringify(cart));
        document.getElementById("numCart").innerHTML=JSON.parse(localStorage.cart).length;
        alert("Product added to cart!");
    }
</script>
<?php get_footer() ?>
