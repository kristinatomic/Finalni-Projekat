<?php get_header() ?>
<div class="cole">
    <?php foreach ($categories as $category): ?>
           <a href=<?='"/products/?category='.$category->id.'"' ?>>
                <img src=<?='"images/products/'.$category->image.'"' ?>/>
                <span><?= $category->title ?></span>
            </a>
        </tr>
    <?php endforeach; ?>
</div>
<div style="clear:both;"></div>
<div id="app">
</div>

<?php /* ispod ovoga su stvari za administratora */ ?>

<?php if(isset($_SESSION["administrator"])) { ?>
    <div class="text-right">
    <a href="/categories/create" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Add New</a>
</div>
<table class="table table-bordered table-striped">
    <tr>
        <th>Title</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($categories as $category): ?>
        <tr>
            <td><?= $category->title ?></td>
            <td style="text-align: center"><a href="/categories/edit?id=<?= $category->id ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Update</a> | <a href="/categories/delete?id=<?= $category->id ?>" class="btn btn-warning btn-sm"><i class="fa fa-trash"></i> Delete</a></td>
        </tr>
    <?php endforeach; ?>
    </table>
<?php }?>

<?php get_footer() ?>
