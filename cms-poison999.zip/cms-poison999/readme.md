1. Clone the project with 

`git clone https://github.com/SAEBelgradeWeb/cms-poison.git`

2. `cd cms-poison`

3. open in editor (PHPStorm)

4. create database 'taskscms'

5. in phpMyAdmin go to database and there Import file taskscms.sql which is in root of the project

6. in the folder of the project run 
`php -S localhost:8080`

7. open in browser 'http://localhost:8080'