<?php
$router->get('login', 'AuthController@showLoginForm');
$router->post('login', 'AuthController@authenticateUser');

$router->get('register', 'AuthController@showRegisterForm');
$router->post('register', 'AuthController@registerUser');

$router->get('logout', 'AuthController@logout');

$router->get('', 'PagesController@home');
$router->get('aboutus', 'PagesController@aboutUs');
$router->get('cart', 'PagesController@cart');
$router->get('posts', 'PostsController@index');
$router->get('posts/create', 'PostsController@create');
$router->post('posts', 'PostsController@store');
$router->get('posts/edit', 'PostsController@edit');
$router->post('posts/update', 'PostsController@update');
$router->get('posts/delete', 'PostsController@delete');



$router->get('categories', 'CategoriesController@index');
$router->get('categories/create', 'CategoriesController@create');
$router->post('categories', 'CategoriesController@store');
$router->get('categories/edit', 'CategoriesController@edit');
$router->post('categories/update', 'CategoriesController@update');
$router->get('categories/delete', 'CategoriesController@delete');

$router->get("products",'PostsController@filter');
$router->get("product",'PostsController@item');

$router->get('users', 'UsersController@index', true);

//API
$router->get('api/users', 'UsersController@apiIndex', true);
$router->get('api/time', 'UsersController@dateTime', true);

$router->get('api/posts', 'PostsController@apiIndex');
$router->post('api/posts', 'PostsController@apiStore');