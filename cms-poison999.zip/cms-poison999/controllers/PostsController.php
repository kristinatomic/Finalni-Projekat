<?php

namespace App\Controllers;


use App\Core\App;

class PostsController
{

    public function index()
    {
        $posts = App::get('database')->getAllPosts();

        return view('posts/index', compact('posts'));
    }
    public function filter()
    {
        $id = isset($_GET["category"])?$_GET["category"]:5;
        $posts = App::get('database')->getCategoryPosts($id);
        return view('posts/index', compact('posts'));
    }
    public function item()
    {
        $id = isset($_GET["id"])?$_GET["id"]:die();
        $posts = App::get('database')->getOnePost($id);
        return view('posts/item', compact('posts'));
    }

    public function create()
    {
        $users = App::get('database')->getAll('users');
        $categories = App::get('database')->getAll('categories');

        return view('posts/create', compact('users', 'categories'));
    }

    public function store()
    {
        App::get('database')->insert('posts', [
            'title' => $_POST['title'],
            'content' => $_POST['content'],
            'user_id' => $_POST['user_id'],
            'image' => $_POST['image'],
            'price' => $_POST['price'],
            'category_id' => $_POST['category_id'],
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        return redirect('/posts');
    }

    public function edit()
    {

        $post = App::get('database')->find('posts', $_GET['id']);

        $users = App::get('database')->getAll('users');
        $categories = App::get('database')->getAll('categories');
        return view('posts/edit', compact('users', 'categories', 'post'));
    }


    public function update()
    {
        App::get('database')->update('posts', [
            'title' => $_POST['title'],
            'content' => $_POST['content'],
            'user_id' => $_POST['user_id'],
            'image' => $_POST['image'],
            'price' => $_POST['price'],
            'category_id' => $_POST['category_id'],
            'updated_at' => date('Y-m-d')
        ], $_POST['id']);

        return redirect('/posts');
    }

    public function delete()
    {
        $id = (int) $_GET['id'];

        if(! is_int($id)) return;

        App::get('database')->delete('posts', $id);

        return redirect('/posts');

    }

    public function apiIndex(){
        $posts = App::get('database')->getAllPosts();
        return json($posts);
    }

    public function apiStore()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);

        App::get('database')->insert('posts', [
            'title' => $_POST['title'],
            'content' => $_POST['content'],
            'price' => $_POST['price'],
            'image' => $_POST['image'],
            'user_id' => 1,
            'category_id' => 1,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        return json(['result' => 'success']);
    }
}