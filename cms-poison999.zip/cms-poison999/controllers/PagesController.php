<?php

namespace App\Controllers;

use App\Core\App;

class PagesController {
    public function home() {

        return view('vue/index');
    }
    public function aboutUs()
    {
    	return view('vue/aboutUs');
    }
     public function cart()
    {
    	return view('vue/cart');
    }


}