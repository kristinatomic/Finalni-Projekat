<?php

namespace App\Controllers;


use App\Core\App;

class AuthController
{
    public function showLoginForm()
    {
        return view('auth/login-form');
    }
    public function showRegisterForm()
    {
        return view('auth/register-form');
    }

    public function authenticateUser()
    {
        if ($_POST['email']=="administrator" && $_POST['password']=="test")
            {
                $_SESSION['user'] = "administrator";
                $_SESSION['administrator'] = '1';
                return redirect('/');
            }
        $user = App::get('database')->authenticate($_POST['email'], md5($_POST['password']));
        if(!$user) {
            return redirect('/login');
        }

        $_SESSION['user'] = $user;

        return redirect('/');
    }
     public function registerUser()
    {
        $user = App::get('database')->register($_POST['email'], md5($_POST['password']));
        if(!$user) {
            return redirect('/register');
        }

        $_SESSION['user'] = $user;
        return redirect('/');
    }

    public function logout()
    {
        unset($_SESSION['user']);
        unset($_SESSION['administrator']);
        return redirect('/login');
    }
}