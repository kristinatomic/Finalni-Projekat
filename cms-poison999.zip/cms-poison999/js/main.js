$('#login-button').on('click', function(){
    $('.login-form').slideDown();
})